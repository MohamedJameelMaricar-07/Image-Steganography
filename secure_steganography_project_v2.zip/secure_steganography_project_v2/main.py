
from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.PublicKey import RSA
from Crypto.Random import get_random_bytes
from PIL import Image
import numpy as np
import base64

def pad(data):
    pad_len = 16 - len(data) % 16
    return data + bytes([pad_len]) * pad_len

def unpad(data):
    pad_len = data[-1]
    return data[:-pad_len]

def aes_encrypt(key, data):
    cipher = AES.new(key, AES.MODE_ECB)
    return cipher.encrypt(pad(data))

def aes_decrypt(key, data):
    cipher = AES.new(key, AES.MODE_ECB)
    return unpad(cipher.decrypt(data))

def embed_text_into_image(image_path, text, output_path):
    img = Image.open(image_path)
    data = np.array(img)
    flat_data = data.flatten()

    bin_text = ''.join(format(byte, '08b') for byte in text)
    if len(bin_text) > len(flat_data):
        raise ValueError("Message is too long to embed in this image.")

    for i in range(len(bin_text)):
        flat_data[i] = (flat_data[i] & ~1) | int(bin_text[i])

    new_data = flat_data.reshape(data.shape)
    stego_image = Image.fromarray(new_data.astype(np.uint8))
    stego_image.save(output_path)

def extract_text_from_image(image_path, length):
    img = Image.open(image_path)
    data = np.array(img).flatten()
    bits = [str(data[i] & 1) for i in range(length * 8)]
    byte_array = [int(''.join(bits[i:i+8]), 2) for i in range(0, len(bits), 8)]
    return bytes(byte_array)

# Main process
key = get_random_bytes(16)
plain_text = open("input/text.txt", "rb").read()
encrypted = aes_encrypt(key, plain_text)

embed_text_into_image("input/plain_image.png", encrypted, "output/stego_image.png")
extracted = extract_text_from_image("output/stego_image.png", len(encrypted))
decrypted = aes_decrypt(key, extracted)

with open("output/encrypted_text.bin", "wb") as f:
    f.write(encrypted)
with open("output/decrypted_text.txt", "w") as f:
    f.write(decrypted.decode())
