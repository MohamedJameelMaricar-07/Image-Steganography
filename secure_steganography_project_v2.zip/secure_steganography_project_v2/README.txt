
Secure Steganography Project (AES + Image)

Files:
- input/plain_image.png: base image to embed into
- input/text.txt: message to encrypt and embed
- output/stego_image.png: image with embedded encrypted message
- output/encrypted_text.bin: AES-encrypted binary data
- output/decrypted_text.txt: final decrypted text

Run main.py to perform all operations.
